-- MindEase schema.sql (trimmed for brevity)
CREATE DATABASE IF NOT EXISTS mindease;
USE mindease;
-- ... (rest of schema from previous response)
